<?php
$flag="flag{zheshiflag}";
?>